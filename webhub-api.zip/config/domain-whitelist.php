<?php

return [
    /*
    |---------------------------------------------
    | Domains to allow
    | Leave empty to allow all requests
    |---------------------------------------------
    */
    'domains' => [
    //    'http://localhost:3000/'
    ],

    /*
    |---------------------------------------------
    | Paths to exclude
    |---------------------------------------------
    */
    'excludes' => [
        //'/api/posts',
    ],
];
